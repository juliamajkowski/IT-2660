package listing;
public class ListingDriver{
    public static void main(String[] args){
        Listing info = new Listing();
        info.Input();
        System.out.println(info.toString());
    }
} 
